import os
from gtts import gTTS

# Simple Auto-Reply Dictionary
replies = {
    "kaise ho": "Main theek hoon, aap kaise ho?",
    "hello": "Hi! Kya haal chaal hain?",
    "naam kya hai": "Mera naam Talking Girl AI hai.",
    "i love you": "Oho! Main toh sirf ek AI hoon.",
    "kya kar rahi ho": "Aap se baatein kar rahi hoon."
}

def game():
    print("==============================")
    print("   🌸 TALKING GIRL V2.0 🌸   ")
    print("==============================")
    
    while True:
        user_text = input("\nAap boliye (exit likhein): ").lower()
        
        if user_text == "exit":
            print("Bye Bye! Phir milenge.")
            break
            
        # Check if we have a reply, otherwise repeat user text
        reply_text = replies.get(user_text, user_text)
        
        try:
            print("Girl is speaking...")
            tts = gTTS(text=reply_text, lang="hi")
            tts.save("v.mp3")
            os.system("ffplay -nodisp -autoexit v.mp3 > /dev/null 2>&1")
            os.remove("v.mp3")
        except:
            print("Internet On rakhein!")

if __name__ == "__main__":
    game()
